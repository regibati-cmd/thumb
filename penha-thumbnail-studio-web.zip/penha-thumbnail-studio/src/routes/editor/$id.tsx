import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { useCallback, useRef, useState } from "react";
import { templates, type Thumb } from "@/lib/templates";
import { ThumbCanvas } from "@/components/ThumbCanvas";

export const Route = createFileRoute("/editor/$id")({
  loader: ({ params }) => { const t = templates.find((x) => x.id === params.id); if (!t) throw notFound(); return t; },
  head: ({ loaderData }) => ({ meta: [
    { title: `Editar ${loaderData?.name ?? "modelo"} — Penha Thumbnail Studio` },
    { name: "description", content: "Personalize textos, cores, fontes, foto e logo e exporte em PNG 1920×1080." },
    { property: "og:title", content: `Editar ${loaderData?.name ?? "modelo"}` },
    { property: "og:description", content: "Editor de thumbnails da Adventistas Penha." },
  ] }),
  component: Editor,
});

const fonts = ["Bricolage Grotesque", "Instrument Serif", "Anton", "Playfair Display", "Montserrat"];

function Editor() {
  const t = Route.useLoaderData();
  const [d, setD] = useState<Thumb>(t.data);
  const canvas = useRef<HTMLCanvasElement | null>(null);
  const onRef = useCallback((c: HTMLCanvasElement) => { canvas.current = c; }, []);
  const set = (k: keyof Thumb, v: string) => setD((p) => ({ ...p, [k]: v }));
  const [removing, setRemoving] = useState(false);
  const file = (k: "photo" | "logo") => async (e: React.ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0]; if (!f) return;
    if (k === "logo") return set(k, URL.createObjectURL(f));
    setRemoving(true);
    try {
      const { removeBackground } = await import("@imgly/background-removal");
      const blob = await removeBackground(f);
      set("photo", URL.createObjectURL(blob));
    } catch { set("photo", URL.createObjectURL(f)); }
    finally { setRemoving(false); }
  };
  const exportPng = () => { const a = document.createElement("a");
    a.download = `thumb-${t.id}.png`; a.href = canvas.current!.toDataURL("image/png"); a.click(); };
  const field = "w-full rounded-lg border border-border bg-input px-3 py-2 text-sm outline-none focus:border-primary";
  const text = (k: keyof Thumb, label: string) => (
    <label className="block"><span className="mb-1 block text-xs text-muted-foreground">{label}</span>
      <input className={field} value={(d[k] as string) ?? ""} onChange={(e) => set(k, e.target.value)} /></label>);
  const color = (k: keyof Thumb, label: string) => (
    <label className="flex flex-1 flex-col gap-1 text-xs text-muted-foreground">{label}
      <input type="color" className="h-10 w-full cursor-pointer rounded-lg border border-border bg-input" value={d[k] as string} onChange={(e) => set(k, e.target.value)} /></label>);

  return (
    <div className="min-h-screen bg-background text-foreground">
      <header className="mx-auto flex max-w-7xl items-center justify-between px-6 py-5">
        <Link to="/" className="text-sm text-muted-foreground hover:text-foreground">← Modelos</Link>
        <div className="font-display font-bold">{t.name}</div>
        <button onClick={exportPng} className="rounded-full bg-primary px-5 py-2 text-sm font-medium text-primary-foreground shadow-glow">Baixar PNG</button>
      </header>
      <div className="mx-auto grid max-w-7xl gap-8 px-6 pb-16 lg:grid-cols-[1fr_360px]">
        <div className="rounded-2xl border border-border bg-card p-3 lg:sticky lg:top-6 lg:self-start"><ThumbCanvas data={d} onRef={onRef} /></div>
        <aside className="space-y-4 rounded-2xl border border-border bg-card p-5">
          {text("title", "Título")}{text("date", "Data e horário")}{text("label", "Chamada")}{text("kind", "Tipo de culto")}{text("footer", "Rodapé")}
          <label className="block"><span className="mb-1 block text-xs text-muted-foreground">Fonte</span>
            <select className={field} value={d.font} onChange={(e) => set("font", e.target.value)}>{fonts.map((f) => <option key={f}>{f}</option>)}</select></label>
          <div className="flex gap-3">{color("c1", "Fundo 1")}{color("c2", "Fundo 2")}{color("accent", "Destaque")}</div>
          <label className="block text-xs text-muted-foreground">Foto<input type="file" accept="image/*" onChange={file("photo")} disabled={removing} className="mt-1 block w-full text-sm" />
            {removing && <span className="mt-1 block text-primary">Removendo fundo… pode levar alguns segundos</span>}</label>
          <label className="block text-xs text-muted-foreground">Logo<input type="file" accept="image/*" onChange={file("logo")} className="mt-1 block w-full text-sm" /></label>
          <button onClick={() => setD(t.data)} className="w-full rounded-lg border border-border py-2 text-sm hover:bg-secondary">Restaurar padrão</button>
        </aside>
      </div>
    </div>
  );
}
