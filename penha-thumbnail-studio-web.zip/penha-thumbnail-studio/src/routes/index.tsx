import { createFileRoute, Link } from "@tanstack/react-router";
import { templates } from "@/lib/templates";
import { ThumbCanvas } from "@/components/ThumbCanvas";

export const Route = createFileRoute("/")({
  head: () => ({ meta: [
    { title: "Penha Thumbnail Studio — Thumbnails para cultos" },
    { name: "description", content: "Crie thumbnails para cultos e transmissões da Adventistas Penha em segundos." },
    { property: "og:title", content: "Penha Thumbnail Studio" },
    { property: "og:description", content: "Três modelos. Cada detalhe nas suas mãos." },
  ] }),
  component: Index,
});

function Index() {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <div className="pointer-events-none fixed inset-0 bg-glow" />
      <header className="relative mx-auto flex max-w-7xl items-center justify-between px-6 py-6">
        <div className="leading-none">
          <div className="font-display text-2xl font-extrabold tracking-tight">PENHA</div>
          <div className="mt-1 text-[10px] tracking-[0.35em] text-muted-foreground">THUMBNAIL STUDIO</div>
        </div>
        <a href="#modelos" className="rounded-full border border-border px-4 py-2 text-sm hover:bg-secondary">Modelos</a>
      </header>

      <section className="relative mx-auto max-w-7xl px-6 pb-20 pt-16 md:pt-28">
        <p className="text-xs tracking-[0.4em] text-primary">UMA MENSAGEM. UM NOVO VISUAL.</p>
        <h1 className="mt-6 max-w-5xl font-display text-5xl font-extrabold leading-[0.95] tracking-tight md:text-8xl">
          O próximo culto <span className="font-serif font-normal italic text-primary">começa</span> por aqui.
        </h1>
        <p className="mt-8 max-w-lg text-lg text-muted-foreground">Três modelos. Cada detalhe nas suas mãos.</p>
        <a href="#modelos" className="mt-10 inline-flex rounded-full bg-primary px-7 py-3.5 font-medium text-primary-foreground shadow-glow transition hover:scale-[1.03]">Escolher modelo →</a>
      </section>

      <section id="modelos" className="relative mx-auto max-w-7xl px-6 pb-24">
        <div className="grid gap-8 md:grid-cols-3">
          {templates.map((t, i) => (
            <Link key={t.id} to="/editor/$id" params={{ id: t.id }}
              className="group rounded-2xl border border-border bg-card p-3 transition hover:-translate-y-1 hover:border-primary/60">
              <div className="overflow-hidden rounded-xl transition group-hover:scale-[1.01]"><ThumbCanvas data={t.data} /></div>
              <div className="flex items-end justify-between px-2 pb-1 pt-4">
                <div>
                  <div className="text-xs text-muted-foreground">0{i + 1}</div>
                  <div className="font-display text-lg font-bold">{t.name}</div>
                  <div className="text-sm text-muted-foreground">{t.desc}</div>
                </div>
                <span className="rounded-full bg-secondary px-3 py-1.5 text-xs group-hover:bg-primary group-hover:text-primary-foreground">Editar</span>
              </div>
            </Link>
          ))}
        </div>
        <div className="mt-14 flex flex-wrap gap-x-10 gap-y-3 border-t border-border pt-6 text-sm text-muted-foreground">
          <span><b className="text-foreground">Editável:</b> textos, cores, fontes, fundo, logo e foto</span>
          <span><b className="text-foreground">Exportação:</b> PNG 1920 × 1080</span>
        </div>
      </section>
    </div>
  );
}
