export type Thumb = {
  date: string; label: string; kind: string; title: string; footer: string;
  c1: string; c2: string; accent: string; font: string; photo?: string; logo?: string;
};
export type Template = { id: string; name: string; desc: string; data: Thumb };

export const templates: Template[] = [
  { id: "sabado", name: "Culto de Sábado", desc: "Edição completa · fundo azul",
    data: { date: "Sábado · 10 de outubro · 10h30", label: "SEU PRÓXIMO CULTO", kind: "CULTO DE SÁBADO",
      title: "A ESPERANÇA QUE TRANSFORMA", footer: "Adventistas Penha", c1: "#0b1e3f", c2: "#0f5c63", accent: "#7fe0d6", font: "Bricolage Grotesque" } },
  { id: "domingo", name: "Culto de Domingo", desc: "Edição completa · fundo verde",
    data: { date: "Domingo · 11 de outubro · 19h", label: "SEU PRÓXIMO CULTO", kind: "CULTO DE DOMINGO",
      title: "O CUIDADO DE DEUS", footer: "Adventistas Penha", c1: "#0f2417", c2: "#3d5a2a", accent: "#c8e07f", font: "Bricolage Grotesque" } },
  { id: "quarta", name: "Culto de Quarta", desc: "Edição completa · fundo cobre",
    data: { date: "Quarta · 14 de outubro · 20h", label: "SEU PRÓXIMO CULTO", kind: "CULTO DE QUARTA",
      title: "ENCONTRO COM DEUS", footer: "Adventistas Penha", c1: "#1f120b", c2: "#8a4a24", accent: "#f2b48a", font: "Bricolage Grotesque" } },
];

const imgCache = new Map<string, HTMLImageElement>();
function loadImg(src: string) {
  return new Promise<HTMLImageElement>((res, rej) => {
    const c = imgCache.get(src); if (c?.complete) return res(c);
    const i = new Image(); i.onload = () => { imgCache.set(src, i); res(i); }; i.onerror = rej; i.src = src;
  });
}

function wrap(ctx: CanvasRenderingContext2D, text: string, max: number) {
  const words = text.split(" "); const lines: string[] = []; let line = "";
  for (const w of words) { const t = line ? line + " " + w : w;
    if (ctx.measureText(t).width > max && line) { lines.push(line); line = w; } else line = t; }
  if (line) lines.push(line); return lines;
}

export async function draw(canvas: HTMLCanvasElement, d: Thumb) {
  const W = 1920, H = 1080; canvas.width = W; canvas.height = H;
  const ctx = canvas.getContext("2d")!;
  await document.fonts?.load(`700 100px "${d.font}"`).catch(() => {});
  const g = ctx.createLinearGradient(0, 0, W, H); g.addColorStop(0, d.c1); g.addColorStop(1, d.c2);
  ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
  if (d.photo) { try { const img = await loadImg(d.photo);
    const s = Math.max((W * 0.5) / img.width, H / img.height); const iw = img.width * s, ih = img.height * s;
    ctx.save(); ctx.globalAlpha = 0.9; ctx.drawImage(img, W - iw, (H - ih) / 2, iw, ih); ctx.restore();
    const fb = ctx.createLinearGradient(0, H * 0.75, 0, H); fb.addColorStop(0, "transparent"); fb.addColorStop(1, d.c2 + "cc");
    ctx.fillStyle = fb; ctx.fillRect(W * 0.5, H * 0.75, W * 0.5, H * 0.25); } catch {} }
  const r = ctx.createRadialGradient(W * 0.85, H * 0.1, 0, W * 0.85, H * 0.1, 900);
  r.addColorStop(0, d.accent + "40"); r.addColorStop(1, "transparent"); ctx.fillStyle = r; ctx.fillRect(0, 0, W, H);
  const P = 120; ctx.textBaseline = "top"; ctx.fillStyle = "#ffffff";
  ctx.font = `500 38px "${d.font}"`; ctx.globalAlpha = 0.85; ctx.fillText(d.date, P, P); ctx.globalAlpha = 1;
  ctx.fillStyle = d.accent; ctx.fillRect(P, 360, 80, 6);
  ctx.font = `600 32px "${d.font}"`; ctx.fillText(d.label.split("").join(String.fromCharCode(8202)), P, 395);
  ctx.fillStyle = "#ffffff"; ctx.font = `500 44px "${d.font}"`; ctx.fillText(d.kind, P, 445);
  ctx.font = `800 132px "${d.font}"`;
  const lines = wrap(ctx, d.title, d.photo ? 1000 : 1500);
  lines.forEach((l, i) => ctx.fillText(l, P, 540 + i * 130));
  ctx.font = `600 34px "${d.font}"`; ctx.globalAlpha = 0.8; ctx.textBaseline = "bottom";
  ctx.fillText(d.footer, P, H - P + 20); ctx.globalAlpha = 1;
  if (d.logo) { try { const l = await loadImg(d.logo); const h = 110, w = (l.width / l.height) * h;
    ctx.drawImage(l, W - P - w, H - P - h + 20, w, h); } catch {} }
}
