import { useEffect, useRef } from "react";
import { draw, type Thumb } from "@/lib/templates";
export function ThumbCanvas({ data, onRef }: { data: Thumb; onRef?: (c: HTMLCanvasElement) => void }) {
  const ref = useRef<HTMLCanvasElement>(null);
  useEffect(() => { if (ref.current) { draw(ref.current, data); onRef?.(ref.current); } }, [data, onRef]);
  return <canvas ref={ref} className="block aspect-video w-full rounded-xl" />;
}
